//
//  AddItemViewController.swift
//  BucketList_laila_
//
//  Created by administrator on 14/12/2021.
//

import UIKit

class AddItemTableViewController: UITableViewController {
    
    weak var delegate: AddItemTableViewControllerDelegate?
    
    var item: String?
    var indexPath: NSIndexPath?
    
    @IBOutlet var ItemTextField: UITextField!
    
    @IBAction func CancelButton(_ sender: UIBarButtonItem) {
        delegate?.CancelButton(by: self)
    }
    
    @IBAction func SaveButton(_ sender: UIBarButtonItem) {
        let text = ItemTextField.text!
        delegate?.ItemSaved(by: self, with: text,at :indexPath)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ItemTextField.text = item
    }
    

    

}
