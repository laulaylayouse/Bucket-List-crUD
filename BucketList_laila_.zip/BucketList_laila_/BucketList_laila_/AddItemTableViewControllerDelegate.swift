//
//  AddItemTableViewControllerDelegate.swift
//  BucketList_laila_
//
//  Created by administrator on 15/12/2021.
//

import UIKit

protocol AddItemTableViewControllerDelegate: AnyObject {
    func ItemSaved(by controller: AddItemTableViewController, with text: String ,at indexPth : NSIndexPath?)
    func CancelButton(by controller: AddItemTableViewController)
    
}
