//
//  CancelButtonDelegate.swift
//  BucketList_laila_
//
//  Created by administrator on 14/12/2021.
//


import UIKit

protocol CancelButtonDelegate: AnyObject{
    func CancelButton(by controller : UIViewController)
}
